# Handoff: About page — gopherthegold.com

## The one rule

**Ship `about.html` as-is. Do not rewrite, reword, shorten, expand, or "improve" any copy.**
Every headline, paragraph, button label, nav item, and footer line in this file is final and approved.
No new sections, no added filler, no placeholder text, no invented stats or team bios.
If something looks like a typo, leave it and flag it to the owner instead of fixing it.

## What this is

`about.html` is a complete, production-ready static page for the "About" route of
https://gopherthegold.com. It is plain HTML + one `<style>` block, no build step, no JS,
no dependencies beyond the Google Fonts link (Kiwi Maru + Public Sans, already used site-wide).

## Install

1. Copy `about.html` to the site root, replacing the existing `about.html` (URL: `/about.html`).
2. Copy `assets/logo-white.svg` and `assets/logo-full-color.svg` into the site's `/assets/` folder
   **only if they aren't already there**. If the site already has equivalents under different
   filenames, repoint the three `<img src>` references instead of duplicating files:
   - header logo (44px), hero logo (280px column), footer logo (32px) -> `/assets/logo-white.svg`
   - closing-section logo (220px) -> `/assets/logo-full-color.svg`
3. Nothing else changes. No other page needs edits.

## Integrating with the existing site chrome

The page ships with its own header and footer that visually match the live site
(dark bar, uppercase nav, sticky). Two acceptable options — pick one, don't blend:

- **Option A (default, zero risk):** keep the header/footer in this file exactly as written.
- **Option B (if the site uses shared includes/templates):** replace the `<header class="site-header">`
  and `<footer class="site-footer">` blocks with the site's existing include, and keep everything
  between them (`.hero`, the three `.way` sections, `.closing`) byte-identical.
  Preserve the active state on the About nav item (`aria-current="page"`).

If Option B is taken, also drop the header/footer CSS rules that become unused — but leave all
other CSS untouched.

## Structure (top to bottom)

| Section | Background | Content |
|---|---|---|
| Header | `#1E2426` | Logo + wordmark, 5 nav links, About marked active |
| Hero | `#1E2426` | Logo, "About us" eyebrow, H1, gold rule, intro paragraph |
| Way one | `#8C6737` | "01" numeral, H2 Write 7 in 7, body, emphasis line, CTA to write7in7.com |
| Way two | `#314939` | "02", H2 own scripts, body, CTA to `/index.html#writers-room` |
| Way three | `#BB5D33` | "03", H2 funding, body, CTA to `/funding.html` |
| Closing | `#ECDABE` | Full-color logo, tagline H2, rule, two CTAs (contact, Instagram) |
| Footer | `#1E2426` | Small logo, tagline, copyright |

## Design tokens (already declared as CSS custom properties)

- ink `#1E2426` · cream `#ECDABE` · gold `#BF833C` · bronze `#8C6737`
- green `#314939` · green-light `#4a6a54` · rust `#BB5D33`
- Display type: Kiwi Maru 500 — H1 76px/1.05, section H2 56px/1.1, closing H2 60px/1.15, numerals 150px/0.9
- Body type: Public Sans — hero 24px/1.55 w500, section body 23px/1.55 w500, emphasis w600
- Labels: Public Sans 800, 14–15px, uppercase, letter-spacing 0.16–0.22em
- Buttons: 18px 32px padding, uppercase 16px w700, letter-spacing 0.1em, square corners (no radius anywhere)
- Content column: `max-width: 1080px`, page padding 48px (24px under 900px)

## Responsive

One breakpoint at `max-width: 900px`: hero and way grids collapse to a single column,
type scales down, padding tightens, nav wraps. Already in the file — no extra work.

## Links used

- Compete / way-one CTA -> `https://write7in7.com`
- Watch / way-two CTA -> `/index.html#writers-room`
- Fund / way-three CTA -> `/funding.html`
- Contact CTA -> `/contact.html`
- Instagram CTA -> `https://instagram.com/gopherthegoldproductions`

Verify each resolves on the live site before publishing; if a path differs, change the `href`
only — never the link text.

## Accessibility notes

Decorative logos have empty `alt`; the header and closing logos carry real alt text.
Heading order is H1 -> H2 with no skips. All text/background pairs clear 4.5:1.
